#include <iostream>

using namespace std;

int main()
{
    double num1, num2;
    char op;

    cout << "Hello Welcome To My calculator, please enter the first number: ";
    cin >> num1;
    cout << "Please enter the op, (x,+,-,:): ";
    cin >> op;
    cout << "please enter the second number: ";
    cin >> num2;
    if(op == 'x'){
        cout << "The Awnser is: " << num2 * num1;
    }else if(op == '+'){
    cout << "the awnser is: " << num1 + num2;
    }else if(op == '-'){
    cout << "the awnser is: " << num1 - num2;
    }else if(op == ':'){
    cout << "the awnser is: " << num1 / num2;
    }else{
    cout << "invaled value";
    }
}
